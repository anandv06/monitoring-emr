#!/bin/bash

# Checking AlertManager status

echo " ==> Check AlertManager Status ####"
alertmanager_status=$(systemctl is-active  alertmanager.service)

if [ "$alertmanager_status" != "unknown" ]
then
 echo “AlertManager is already present and status is $alertmanager_status”
 exit;
else
 echo “AlertManager Service is not Installed”
 echo "Starting Installation"

# Make alertmanager user
echo " ==> Creating Alertmanager User #### "
sudo useradd --no-create-home -s /bin/false -c "Alertmanager User" alertmanager

# Make directories and dummy files necessary for alertmanager
echo " ==> Creating required directories and files ####"
sudo mkdir -p /etc/alertmanager
sudo mkdir -p /etc/alertmanager/template
sudo mkdir -p /var/lib/alertmanager/data
sudo touch /etc/alertmanager/alertmanager.yml

# Assign ownership of the files above to alertmanager user
echo " ==> Changing Ownership of the files above to alertmanager user ####"
sudo chown -R alertmanager:alertmanager /etc/alertmanager
sudo chown -R alertmanager:alertmanager /var/lib/alertmanager

# Download alertmanager and copy utilities to where they should be in the filesystem
VERSION=0.22.2
#VERSION=$(curl https://raw.githubusercontent.com/prometheus/alertmanager/master/VERSION)
#wget https://github.com/prometheus/alertmanager/releases/download/v${VERSION}/alertmanager-${VERSION}.linux-amd64.tar.gz

# Extracting Alertmanager
echo " ==> Installing alertmanager ####"
tar -xvzf alertmanager-${VERSION}.linux-amd64.tar.gz

# Copy the alertmanager server to neccessary folder
echo " ==> Copying alertmanager server file to required folder ####"
sudo cp alertmanager-${VERSION}.linux-amd64/alertmanager /usr/local/bin/
sudo cp alertmanager-${VERSION}.linux-amd64/amtool /usr/local/bin/
sudo chown alertmanager:alertmanager /usr/local/bin/alertmanager
sudo chown alertmanager:alertmanager /usr/local/bin/amtool

# Populate configuration files
echo " ==> Copying alertmanager config files to ####"
cat ./alertmanager-${VERSION}.linux-amd64/alertmanager.yml | sudo tee /etc/alertmanager/alertmanager.yml
cat ./alertmanager.service | sudo tee /etc/systemd/system/alertmanager.service

# Start the server with systemd
echo " ==> Configure the alertmanager server to start at boot ####"
sudo systemctl daemon-reload
sudo systemctl enable alertmanager
sudo systemctl start alertmanager

# Installation cleanup
#rm alertmanager-${VERSION}.linux-amd64.tar.gz
#rm -rf alertmanager-${VERSION}.linux-amd64

fi

