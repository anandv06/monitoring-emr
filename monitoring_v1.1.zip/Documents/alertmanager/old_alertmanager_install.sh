#!/bin/bash

# Make alertmanager user
sudo useradd --no-create-home -s /bin/false -c "Alertmanager User" alertmanager

# Make directories and dummy files necessary for alertmanager
sudo mkdir -p /etc/alertmanager
sudo mkdir -p /etc/alertmanager/template
sudo mkdir -p /var/lib/alertmanager/data
sudo touch /etc/alertmanager/alertmanager.yml


sudo chown -R alertmanager:alertmanager /etc/alertmanager
sudo chown -R alertmanager:alertmanager /var/lib/alertmanager

# Download alertmanager and copy utilities to where they should be in the filesystem
VERSION=0.22.2
#VERSION=$(curl https://raw.githubusercontent.com/prometheus/alertmanager/master/VERSION)
#wget https://github.com/prometheus/alertmanager/releases/download/v${VERSION}/alertmanager-${VERSION}.linux-amd64.tar.gz
#tar xvzf alertmanager-${VERSION}.linux-amd64.tar.gz

sudo cp alertmanager-${VERSION}.linux-amd64/alertmanager /usr/local/bin/
sudo cp alertmanager-${VERSION}.linux-amd64/amtool /usr/local/bin/
sudo chown alertmanager:alertmanager /usr/local/bin/alertmanager
sudo chown alertmanager:alertmanager /usr/local/bin/amtool

# Populate configuration files
cat ./alertmanager-${VERSION}.linux-amd64/alertmanager.yml | sudo tee /etc/alertmanager/alertmanager.yml
cat ./alertmanager.service | sudo tee /etc/systemd/system/alertmanager.service

# systemd
sudo systemctl daemon-reload
sudo systemctl enable alertmanager
sudo systemctl start alertmanager

# Installation cleanup
#rm alertmanager-${VERSION}.linux-amd64.tar.gz
#rm -rf alertmanager-${VERSION}.linux-amd64

Testing :

#!/bin/bash

# Make alertmanager user
sudo useradd --no-create-home -s /bin/false -c "Alertmanager User" alertmanager

# Make directories and dummy files necessary for alertmanager
sudo mkdir -p /etc/alertmanager
sudo mkdir -p /etc/alertmanager/template
sudo mkdir -p /var/lib/alertmanager/data
sudo touch /etc/alertmanager/alertmanager.yml


sudo chown -R alertmanager:alertmanager /etc/alertmanager
sudo chown -R alertmanager:alertmanager /var/lib/alertmanager

# Download alertmanager and copy utilities to where they should be in the filesystem
VERSION=0.22.2
#VERSION=$(curl https://raw.githubusercontent.com/prometheus/alertmanager/master/VERSION)
#wget https://github.com/prometheus/alertmanager/releases/download/v${VERSION}/alertmanager-${VERSION}.linux-amd64.tar.gz
#tar xvzf alertmanager-${VERSION}.linux-amd64.tar.gz

sudo cp alertmanager-${VERSION}.linux-amd64/alertmanager /usr/local/bin/
sudo cp alertmanager-${VERSION}.linux-amd64/amtool /usr/local/bin/
sudo chown alertmanager:alertmanager /usr/local/bin/alertmanager
sudo chown alertmanager:alertmanager /usr/local/bin/amtool

# Populate configuration files
cat /data/prometheus/alertmanager-${VERSION}.linux-amd64/alertmanager.yml | sudo tee /etc/alertmanager/alertmanager.yml
cat /data/prometheus/alertmanager.service | sudo tee /etc/systemd/system/alertmanager.service

# systemd
sudo systemctl daemon-reload
sudo systemctl enable alertmanager
sudo systemctl start alertmanager

# Installation cleanup
#rm alertmanager-${VERSION}.linux-amd64.tar.gz
#rm -rf alertmanager-${VERSION}.linux-amd64


[root@ip-172-31-1-117 prometheus]# systemctl status alertmanager.service 
● alertmanager.service - Prometheus Alert Manager service
   Loaded: loaded (/etc/systemd/system/alertmanager.service; enabled; vendor preset: disabled)
   Active: active (running) since Mon 2021-08-02 11:09:03 UTC; 11min ago
 Main PID: 2796 (alertmanager)
   CGroup: /system.slice/alertmanager.service
           └─2796 /usr/local/bin/alertmanager --config.file /etc/alertmanager/alertmanager.yml --storage.path /var/lib/alertmanager/data

Aug 02 11:09:03 ip-172-31-1-117.us-east-2.compute.internal alertmanager[2796]: level=info ts=2021-08-02T11:09:03.659Z caller=main.go:221 msg="Starting Alertmanager" version="(version=0.22.2, ...f2922051)"
Aug 02 11:09:03 ip-172-31-1-117.us-east-2.compute.internal alertmanager[2796]: level=info ts=2021-08-02T11:09:03.660Z caller=main.go:222 build_context="(go=go1.16.4, user=root@b595c7f32520, d...07:50:37)"
Aug 02 11:09:03 ip-172-31-1-117.us-east-2.compute.internal alertmanager[2796]: level=info ts=2021-08-02T11:09:03.665Z caller=cluster.go:184 component=cluster msg="setting advertise address ex... port=9094
Aug 02 11:09:03 ip-172-31-1-117.us-east-2.compute.internal alertmanager[2796]: level=info ts=2021-08-02T11:09:03.680Z caller=cluster.go:671 component=cluster msg="Waiting for gossip to settle...nterval=2s
Aug 02 11:09:03 ip-172-31-1-117.us-east-2.compute.internal alertmanager[2796]: level=info ts=2021-08-02T11:09:03.802Z caller=coordinator.go:113 component=configuration msg="Loading configurat...anager.yml
Aug 02 11:09:03 ip-172-31-1-117.us-east-2.compute.internal alertmanager[2796]: level=info ts=2021-08-02T11:09:03.808Z caller=coordinator.go:126 component=configuration msg="Completed loading ...anager.yml
Aug 02 11:09:03 ip-172-31-1-117.us-east-2.compute.internal alertmanager[2796]: level=info ts=2021-08-02T11:09:03.818Z caller=main.go:514 msg=Listening address=:9093
Aug 02 11:09:03 ip-172-31-1-117.us-east-2.compute.internal alertmanager[2796]: level=info ts=2021-08-02T11:09:03.818Z caller=tls_config.go:191 msg="TLS is disabled." http2=false
Aug 02 11:09:05 ip-172-31-1-117.us-east-2.compute.internal alertmanager[2796]: level=info ts=2021-08-02T11:09:05.718Z caller=cluster.go:696 component=cluster msg="gossip not settled" polls=0 ...037938152s
Aug 02 11:09:13 ip-172-31-1-117.us-east-2.compute.internal alertmanager[2796]: level=info ts=2021-08-02T11:09:13.721Z caller=cluster.go:688 component=cluster msg="gossip settled; proceeding" ...0.0403326s
Hint: Some lines were ellipsized, use -l to show in full.
[root@ip-172-31-1-117 prometheus]# 
