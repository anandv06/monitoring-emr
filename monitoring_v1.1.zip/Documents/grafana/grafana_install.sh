#!/bin/bash

# Checking Grafana status
echo " ==> Check Grafana Status ####"
grafana_status=$(systemctl is-active  grafana-server.service)

if [ "$grafana_status" != "unknown" ]
then
 echo “Grafana is already present and status is $grafana_status”
 exit;
else
 echo “Grafana Service is not Installed”
 echo " ==> Starting Installation"

# Make grafana user
echo " ==> Creating Grafana User #### "
sudo useradd --no-create-home -c "grafana user" -s /bin/false grafana

# Make directories and dummy files necessary for grafana
echo " ==> Creating required directories ####"
sudo mkdir -p /data/monitoring/grafana/{data,logs}

# Assign ownership of the files above to grafana user
echo " ==> Changing Ownership of the files above to grafana user ####"
sudo chown -R grafana:grafana /data/monitoring/grafana

# Download grafana
VERSION=8.0.6-1
echo "## Downloading Prometheus binary ##"
#curl -k -H "Host:artifactory.dev-test.axisb.com" -O https://127.0.0.1/artifactory/packages/monitoring/grafana

# Install grafana
echo " ==> Installing grafana ####"
sudo yum install grafana-${VERSION}.x86_64.rpm

# Copy the sample.ini to neccessary folders
echo " ==> Copying sample.ini to required folder & Changing Ownership ####"
cp ./custom.ini /etc/grafana/custom.ini
sudo chown grafana:grafana /etc/grafana/custom.ini

# Copy the grafana-server to neccessary folder
echo " ==> Copying grafana-server file to required folder ####"
cp ./grafana-server /etc/sysconfig/grafana-server

# Start the server with systemd
echo " ==> Configure the Grafana server to start at boot ####"
sudo systemctl daemon-reload
sudo systemctl enable grafana-server
sudo systemctl start grafana-server

# Installation cleanup

#rm grafana-${VERSION}.x86_64.rpm

fi

