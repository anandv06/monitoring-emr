#!/bin/bash

# Make grafana user
sudo useradd --no-create-home -c "grafana user" -s /bin/false grafana

# Make directories and dummy files necessary for grafana
sudo mkdir -p /data/monitoring/grafana/{data,logs}

# Assign ownership of the files above to grafana user
sudo chown -R grafana:grafana /data/monitoring/grafana

# Download grafana
VERSION=8.0.6-1
#echo "## Downloading Prometheus binary ##"
#curl -k -H "Host:artifactory.dev-test.axisb.com" -O https://127.0.0.1/artifactory/packages/monitoring/grafana

# Install grafana
sudo yum install grafana-${VERSION}.x86_64.rpm

cp ./custom.ini /etc/grafana/custom.ini
sudo chown grafana:grafana /etc/grafana/custom.ini

# Assign the ownership of the tools above to prometheus user
cp ./grafana-server /etc/sysconfig/grafana-server

# systemd
sudo systemctl daemon-reload
sudo systemctl enable grafana-server
sudo systemctl start grafana-server

# Installation cleanup
#rm grafana-${VERSION}.x86_64.rpm

