#! /bin/bash

# Checking Prometheus status

echo " ==> Check Prometheus Status ####"
prometheus_status=$(systemctl is-active  prometheus.service)

if [ "$prometheus_status" != "unknown" ]
then
 echo "prometheus is already present and status is $prometheus_status"
 exit;
else
 echo "prometheus Service is not running"
 echo "Starting Installation"

 # Make prometheus user
 echo " ==> Creating Prometheus User #### "
 sudo useradd --no-create-home -c "prometheus user" -s /bin/false prometheus

 # Make directories necessary for prometheus
 echo " ==> Creating required directories ####"
 sudo mkdir -p /data/monitoring/prometheus/{data,config,bin,logs,rules}

 # Assign ownership of the files above to prometheus user
 echo " ==> Changing Ownership of the files above to prometheus user ####"
 sudo chown -R prometheus:prometheus /data/monitoring/prometheus

 # Download prometheus and copy utilities to where they should be in the filesystem
 VERSION=2.28.1
 echo "## Downloading Prometheus binary ##"
 #curl -k -H "Host:artifactory.dev-test.axisb.com" -O https://127.0.0.1/artifactory/packages/prometheus
 tar -xvzf prometheus-${VERSION}.linux-amd64.tar.gz

 # Copy the directories and files necessary for to neccessary folders
 echo " ==> Copying files required folder & Changing Ownership ####"
 sudo cp prometheus-${VERSION}.linux-amd64/prometheus /data/monitoring/prometheus/bin/
 sudo cp prometheus-${VERSION}.linux-amd64/promtool /data/monitoring/prometheus/bin/
 sudo cp -r prometheus-${VERSION}.linux-amd64/consoles /data/monitoring/prometheus
 sudo cp -r prometheus-${VERSION}.linux-amd64/console_libraries /data/monitoring/prometheus

 # Assign the ownership of the tools above to prometheus user
 echo " ==> Changing Ownership of the files above to prometheus user ####"
 sudo chown -R prometheus:prometheus /data/monitoring/prometheus/consoles
 sudo chown -R prometheus:prometheus /data/monitoring/prometheus/console_libraries
 sudo chown prometheus:prometheus /data/monitoring/prometheus/bin/prometheus
 sudo chown prometheus:prometheus /data/monitoring/prometheus/bin/promtool

 # Populate configuration files
 echo " ==> Copying neccessary files to required folder & Changing Ownership ####"
 cat ./prometheus.yml | sudo tee /data/monitoring/prometheus/prometheus.yml
 cat ./prometheus.rules.yml | sudo tee /data/monitoring/prometheus/rules/prometheus.rules.yml
 cat ./prometheus.service | sudo tee /etc/systemd/system/prometheus.service

 # systemd - Create service file for Prometheus
 echo " ==> Configure the Grafana server to start at boot ####"
 sudo systemctl daemon-reload
 sudo systemctl enable prometheus
 sudo systemctl start prometheus

 # Installation cleanup
 #rm prometheus-${VERSION}.linux-amd64.tar.gz
 #rm -rf prometheus-${VERSION}.linux-amd64

fi
